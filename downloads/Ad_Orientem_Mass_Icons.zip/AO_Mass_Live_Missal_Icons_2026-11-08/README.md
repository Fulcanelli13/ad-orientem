# Ad Orientem: LIVE / MISSAL Mass icon export
Source repository: https://github.com/Fulcanelli13/ad-orientem
Source revision: 433454a58af0957129e64eafab484f56275e40e4

The assets directory contains original source PNG/SVG files, not generated replacements.
01_ICON_FILES lists icon hashes/keys.
02_CUE_ASSIGNMENTS lists the 414 source crosswalk entries plus exact LIVE,
conditional approved extension and text-only/suppression assignments.
03_LIVE_CARDS maps the source-backed LIVE 65 baseline and optional supported pre-Gospel split(s).
04_MISSAL_PAGES maps source-granular Missal pages.
05_ALL_MOMENTS contains all 1962 ordinary source cues, including text-only.
06_CANONICAL_MEANINGS maps semantic meaning to approved source artwork.
REGISTRY.json is the complete machine-readable export.
sources/ retains authoritative registries and the user rejection lock.

Important: SOURCE assignment is NOT proof an icon appears in every form,
moment or reading state. Runtime source state, priest/minister actor, rite
and local conditions govern display. Null artwork and rejected Foot Centre
substitutions remain text-only. V4.6 SVG files sometimes embed pixel art.
Special-rite overlays are not misrepresented as ordinary 65-card events.

iconFiles: 80
sourceCrosswalk: 414
assignmentRows: 1290
liveCardsPerForm: 66
missalPagesPerForm: 67
cues: 280
missingArtMeanings: 2
